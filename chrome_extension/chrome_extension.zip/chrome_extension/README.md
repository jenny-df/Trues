# Create a Chrome extension to modify a website's HTML or CSS

See post: https://blog.lateral.io/2016/04/create-chrome-extension-modify-websites-html-css/
